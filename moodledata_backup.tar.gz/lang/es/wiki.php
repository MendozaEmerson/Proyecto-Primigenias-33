<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'wiki', language 'es', version '4.5'.
 *
 * @package     wiki
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addcomment'] = 'Agregar comentario';
$string['addedbegins'] = 'Fin de eliminadas';
$string['addedends'] = 'Fin de agregadas';
$string['admin'] = 'Administración';
$string['adminmenu'] = 'Menú de administración';
$string['attachmentattach'] = 'Agregar como anexo';
$string['attachmentimage'] = 'Agregar como imagen';
$string['attachmentlink'] = 'Agregar como enlace';
$string['attachments'] = 'Anexos';
$string['backcomments'] = 'Regresar a comentarios';
$string['backhistory'] = 'Regresar a historia';
$string['backoldversion'] = 'Regresar a versión antigua';
$string['backpage'] = 'Regresar a página';
$string['backtomapmenu'] = 'Regresar a menú del mapa';
$string['cannotcomparenewerversion'] = 'Una versión de página sólo se puede comparar con una versión anterior.';
$string['cannoteditpage'] = 'No puede editar esta página.';
$string['cannotmanagefiles'] = 'No tienes permiso para administrar los ficheros del wiki.';
$string['cannotviewfiles'] = 'No tienes permiso para ver los ficheros del wiki.';
$string['cannotviewpage'] = 'No puede ver esta página.';
$string['changerate'] = '¿Desea cambiarlo?';
$string['comments'] = 'Comentarios';
$string['commentscount'] = 'Comentarios ({$a})';
$string['comparesel'] = 'Comparar seleccionados';
$string['comparewith'] = 'Comparando la versión {$a->old} con la versión {$a->new}';
$string['contributions'] = 'Contribuciones';
$string['contributions_help'] = 'Lista de páginas que usted ha editado.';
$string['createcomment'] = 'Creando comentario';
$string['createddate'] = 'Creado en: {$a->date} por {$a->username}';
$string['createpage'] = 'Crear página';
$string['creating'] = 'Creando página wiki';
$string['creole'] = 'Creole';
$string['defaultformat'] = 'Formato por defecto';
$string['defaultformat_help'] = 'Este ajuste determina el formato por defecto usado cuando se editan páginas wiki.

* HTML - El editor HTML está disponible
* Creole - Lenguaje común de marcas wiki que tiene disponible una pequeña barra de herramientas de edición
* Nwiki - Lenguaje de marcas parecido al Mediawiki usado en el módulo Nwiki';
$string['deleteallpages'] = 'todas las páginas wiki.';
$string['deletecomment'] = 'Eliminando comentario';
$string['deletecommentcheck'] = 'Eliminar comentario';
$string['deletecommentcheckfull'] = '¿Seguro que quieres eliminar el comentario?';
$string['deletedbegins'] = 'Comienzo de eliminadas';
$string['deletedends'] = 'Fin de eliminadas';
$string['deleteupload'] = 'Eliminar';
$string['deleteversions'] = 'Eliminar las versiones de la página';
$string['diff'] = 'Diferencias';
$string['diff_help'] = 'Se pueden comparar las versiones seleccionadas de la página con el fin de encontrar diferencias.';
$string['edit'] = 'Editar';
$string['editblocks'] = 'Activar la edición de bloques';
$string['editcomment'] = 'Editar comentario';
$string['editfiles'] = 'Editar ficheros del wiki';
$string['editing'] = 'Editando página de la wiki';
$string['editingcomment'] = 'Editando comentario';
$string['editingpage'] = 'Editando esta página \'{$a}\'';
$string['editsection'] = 'Editar';
$string['eventdiffviewed'] = 'Diff de la wiki visto';
$string['eventhistoryviewed'] = 'Historia de la wiki vista';
$string['eventmapviewed'] = 'Mapa de la página wiki visto';
$string['eventpagecreated'] = 'Página wiki creada';
$string['eventpagedeleted'] = 'Página wiki borrada';
$string['eventpagelocksdeleted'] = 'Bloqueos de la página wiki borrados';
$string['eventpageupdated'] = 'Página de la wiki actualizada';
$string['eventpageversiondeleted'] = 'Versión de la página wiki borrada';
$string['eventpageviewed'] = 'Página wiki vista';
$string['eventversionrestored'] = 'Versión de la wiki restablecida';
$string['eventversionviewed'] = 'Versión de la página wiki vista';
$string['filenotuploadederror'] = 'El archivo \'{$a}\' no se pudo subir correctamente.';
$string['files'] = 'Ficheros';
$string['filtername'] = 'Auto-enlace de página Wiki';
$string['firstpagetitle'] = 'Nombre de la primera página';
$string['firstpagetitle_help'] = 'Título de la primera página del wiki. Una vez que el wiki es creado, el título ya no podrá ser cambiado.';
$string['forceformat'] = 'Forzar formato';
$string['forceformat_help'] = 'Si se fuerza el formato (casilla marcada), no hay opción para elegir un formato cuando se edite la página wiki.';
$string['format'] = 'Formato';
$string['format_help'] = '* HTML - El editor HTML está disponible
* Creole - Lenguaje común de marcas wiki que tiene disponible una pequeña barra de herramientas de edición
* Nwiki - Lenguaje de marcas parecido al Mediawiki usado en el módulo Nwiki';
$string['formatcreole'] = 'Formato Creole';
$string['formatcreole_help'] = 'Creole es un lenguaje de marcas de wiki habitual con una barra de herramientas de edición para la inserción de las marcas apropiadas.

Para crear una nueva página, escribe el nombre de la nueva página entre corchetes dobles, por ejemplo [[Página 2]].';
$string['formatcreole_link'] = 'mod/wiki/creole';
$string['formathtml'] = 'Formato HTML';
$string['formathtml_help'] = 'El editor de HTML se pueden utilizar para dar formato a contenidos. Para crear una nueva página, escriba el nombre de la página encerrada entre corchetes dobles, por ejemplo [[Página 2]].';
$string['formatnwiki'] = 'Formato NWiki';
$string['formatnwiki_help'] = 'Nwiki es el lenguaje de marcas del tipo de Mediawiki usado en el módulo Nwiki.

Para crear una página nueva, escriba el nombre de la página dentro de corchetes dobles, p.ej., [[Página 2]].';
$string['formatnwiki_link'] = 'mod/wiki/nwiki';
$string['history'] = 'Historia';
$string['history_help'] = 'Historia de las listas de enlaces a las versiones anteriores de la página.';
$string['html'] = 'HTML';
$string['incorrectdeleteversions'] = 'Las versiones de página indicadas para eliminar son incorrectas.';
$string['incorrectpageid'] = 'El ID de página es incorrecto.';
$string['incorrectsubwikiid'] = 'El ID de subwiki es incorrecto';
$string['incorrectwikiid'] = 'El ID de la wiki es incorrecto.';
$string['indicator:cognitivedepth'] = 'Wiki cognitiva';
$string['indicator:cognitivedepth_help'] = 'Este indicador está basado en la profundidad cognitiva alcanzada por el estudiante en una actividad de Wiki.';
$string['indicator:cognitivedepthdef'] = 'Wiki cognitivo';
$string['indicator:cognitivedepthdef_help'] = 'El participante ha alcanzado este porcentaje del compromiso cognitivo ofrecido por las actividades de Wiki durante este intervalo de análisis (Niveles = Sin vista, Vista, Enviar)';
$string['indicator:cognitivedepthdef_link'] = 'Learning_analytics_indicators#Cognitive_depth';
$string['indicator:socialbreadth'] = 'Wiki social';
$string['indicator:socialbreadth_help'] = 'Este indicador está basado en la amplitud social alcanzada por el estudiante en una actividad de Wiki.';
$string['indicator:socialbreadthdef'] = 'Wiki social';
$string['indicator:socialbreadthdef_help'] = 'El participante ha alcanzado este porcentaje de compromiso social ofrecido por las actividades de Wiki durante este intervalo de análisis (Niveles = Sin participación, Participante solo, Participante con otros)';
$string['indicator:socialbreadthdef_link'] = 'Learning_analytics_indicators#Social_breadth';
$string['individualpagedoesnotexist'] = 'La página individual wiki no existe';
$string['insertcomment'] = 'Insertar comentario';
$string['insertimage'] = 'Inserta una imagen...';
$string['insertimage_help'] = 'Este menú desplegable insertará una imagen en el editor del wiki. Si necesitas añadir más imágenes, por favor usa la pestaña "Ficheros".';
$string['invalidlock'] = 'Esta página ya está bloqueada por otro usuario.';
$string['invalidparameters'] = 'Se han suministrado parámetros no válidos.';
$string['invalidsection'] = 'Sección no válida.';
$string['invalidsesskey'] = 'Su sesión muy probablemente ha caducado. Por favor tome nota de sus ediciones e inicie sesión de nuevo.';
$string['javascriptdisabledlocks'] = 'Javascript está desactivado en su navegador y los cierres no están funcionando. Los cambios que realice pueden no guardarse correctamente.';
$string['links'] = 'Enlaces';
$string['listall'] = 'Mostrar todo';
$string['listorphan'] = 'Mostrar huérfanas';
$string['lockingajaxtimeout'] = 'Hora de refresco del bloqueo de la edición de página';
$string['lockingtimeout'] = 'Tiempo de espera para el bloqueo';
$string['map'] = 'Mapa';
$string['mapmenu'] = 'Menú Mapa';
$string['migrationfinished'] = 'La migración finalizó con éxito';
$string['migrationfinishednowikis'] = 'Migración terminada, no se migró ninguna wiki';
$string['missingpages'] = 'Páginas sin contenido';
$string['modified'] = 'Modificado';
$string['modulename'] = 'Wiki';
$string['modulename_help'] = 'El módulo de actividad wiki le permite a los participantes añadir y editar una colección de páginas web. Un wiki puede ser colaborativo, donde todos pueden editarlo, o puede ser individual, donde cada persona tiene su propio wiki que solamente ella podrá editar.

Se conserva un histórico de las versiones previas de cada página del wiki, permitiendo consultar los cambios hechos por cada participante.

Los wikis tienen muchos usos, como por ejemplo:

* Para generar unos apuntes de clase colaborativamente entre todos
* Para  los profesores de una escuela que planean una estrategia o reunión de trabajo en equipo
* Para estudiantes que trabajarán en equipo en un libro en línea, creando contenidos de un tema elegido por sus tutores
* Para la narración colaborativa o creación de poesía grupal, donde cada participante escribe una línea o un verso
* Como un diario personal para apuntes para examen o resúmenes (wiki personal)';
$string['modulename_link'] = 'mod/wiki/view';
$string['modulenameplural'] = 'Wikis';
$string['navigation'] = 'Navegación';
$string['navigationfrom'] = 'Esta página proviene de';
$string['navigationfrom_help'] = 'Páginas wiki enlazadas a esta página';
$string['navigationto'] = 'Está página lleva hacia';
$string['navigationto_help'] = 'Enlaces a otras páginas';
$string['newpage'] = 'Nuevo';
$string['newpagehdr'] = 'Página nueva';
$string['newpagetitle'] = 'Título nuevo de la página';
$string['noattachments'] = '<strong>no hay archivos adjuntos </strong>';
$string['nocomments'] = 'No hay comentarios';
$string['nocontent'] = 'No hay contenido para esta página';
$string['nocontribs'] = 'Usted no ha hecho contribuciones a esta wiki';
$string['nocreatepermission'] = 'Se necesitan permisos para crear la página';
$string['noeditcommentpermission'] = 'Se necesitan permisos para crear comentarios';
$string['noeditpermission'] = 'Se necesitan permisos para editar la página';
$string['nofrompages'] = 'No hay enlaces a esta página';
$string['nohistory'] = 'No hay historia para esta página';
$string['nomanagecommentpermission'] = 'Denegado permiso para gestionar comentarios';
$string['nomanagewikipermission'] = 'Se necesita permiso para gestionar la wiki';
$string['noorphanedpages'] = 'No hay páginas huérfanas';
$string['nooverridelockpermission'] = 'Se necesita permiso de anulación del bloqueo';
$string['norated'] = '¡Sea el primero en calificar esta página!';
$string['norating'] = 'Sin puntuaciones';
$string['nosearchresults'] = 'Sin resultados';
$string['noteditblocks'] = 'Desactivar la edición de bloques';
$string['notingroup'] = 'No está en un grupo';
$string['notmigrated'] = 'Esta wiki aún no ha migrado. Por favor, contacte con su administrador.';
$string['notopages'] = 'Esta página no está enlazada a otras páginas';
$string['noupdatedpages'] = 'No hay páginas actualizadas';
$string['noviewcommentpermission'] = 'Se necesita permiso para ver comentarios';
$string['noviewpagepermission'] = 'Denegado permiso para ver páginas';
$string['nwiki'] = 'NWiki';
$string['oldversion'] = 'Versión antigua';
$string['orphaned'] = 'Páginas huérfanas';
$string['orphaned_help'] = 'Listado de páginas que no están enlazadas desde otras páginas';
$string['overridelocks'] = 'Anular bloqueos';
$string['overridinglocks'] = 'Anulando bloqueos...';
$string['page-mod-wiki-comments'] = 'Página de comentarios del módulo Wiki';
$string['page-mod-wiki-history'] = 'Página del histórico del Wiki';
$string['page-mod-wiki-map'] = 'Página del mapa del Wiki';
$string['page-mod-wiki-view'] = 'Página principal del módulo Wiki';
$string['page-mod-wiki-x'] = 'Cualquier página del módulo Wiki';
$string['pageexists'] = 'Esta página ya existe.';
$string['pageindex'] = 'Índice de la página';
$string['pageindex_help'] = 'Árbol de esta página wiki';
$string['pageislocked'] = 'Alguien está editando esta página en este momento. Intente editarla dentro de unos minutos.';
$string['pagelist'] = 'Lista de páginas';
$string['pagelist_help'] = 'Lista de páginas categorizada por orden alfabético';
$string['pagename'] = 'Nombre de la página';
$string['peerreview'] = 'Revisión por pares';
$string['pluginadministration'] = 'Administración wiki';
$string['pluginname'] = 'Wiki';
$string['prettyprint'] = 'Versión imprimible';
$string['previewwarning'] = 'Esta es una vista previa. Los cambios aún no se han guardado.';
$string['print'] = 'Imprimir';
$string['privacy:metadata:core_comment'] = 'Comentarios en la página wiki';
$string['privacy:metadata:core_files'] = 'Archivos adjuntos a subwikis';
$string['privacy:metadata:core_tag'] = 'Etiquetas asociadas con páginas wiki';
$string['privacy:metadata:wiki_locks'] = 'Almacenamiento temporal para bloqueos de edición wiki';
$string['privacy:metadata:wiki_locks:lockedat'] = 'Fecha cuando está bloqueado';
$string['privacy:metadata:wiki_locks:sectionname'] = 'Nombre de la sección de página bloqueada';
$string['privacy:metadata:wiki_locks:userid'] = 'Usuario que bloqueó una página';
$string['privacy:metadata:wiki_pages'] = 'Información sobre páginas wiki';
$string['privacy:metadata:wiki_pages:cachedcontent'] = 'Contenido en caché en formato HTML';
$string['privacy:metadata:wiki_pages:pageviews'] = 'Número de veces que se vio la página';
$string['privacy:metadata:wiki_pages:readonly'] = 'Si una página es de solo lectura';
$string['privacy:metadata:wiki_pages:timecreated'] = 'Momento en el que la página fue creada';
$string['privacy:metadata:wiki_pages:timemodified'] = 'Momento en el que la página fue modificada por última vez';
$string['privacy:metadata:wiki_pages:timerendered'] = 'Momento en el que la página fue renderizada por última vez';
$string['privacy:metadata:wiki_pages:title'] = 'Nombre de la página';
$string['privacy:metadata:wiki_pages:userid'] = 'El último usuario que editó la página';
$string['privacy:metadata:wiki_subwikis'] = 'Información sobre subwikis (en caso de modo grupal o individual)';
$string['privacy:metadata:wiki_subwikis:groupid'] = 'Grupo propietario de la subwiki';
$string['privacy:metadata:wiki_subwikis:userid'] = 'Usuario que posee una subwiki (para wikis individuales)';
$string['privacy:metadata:wiki_versions'] = 'Información sobre el historial de páginas wiki';
$string['privacy:metadata:wiki_versions:content'] = 'Contenido de la revisión';
$string['privacy:metadata:wiki_versions:contentformat'] = 'Formato del contenido de la revisión';
$string['privacy:metadata:wiki_versions:timecreated'] = 'Momento en el que la revisión fue creada';
$string['privacy:metadata:wiki_versions:userid'] = 'Usuario que creó la revisión';
$string['privacy:metadata:wiki_versions:version'] = 'Número de versión';
$string['rated'] = 'Usted clasificó esta página como {$a}';
$string['rating'] = 'Clasificación';
$string['ratingmode'] = 'Modo de clasificación';
$string['removeallwikitags'] = 'Todas las marcas wiki';
$string['removepages'] = 'Eliminar páginas';
$string['reparsetimeout'] = 'Reanalizando tiempo de espera por defecto';
$string['repeatedsection'] = 'Error wiki: El nombre de la sección no puede repetirse \'{$a}\'';
$string['restore'] = 'Restaurar';
$string['restoreconfirm'] = '¿Está seguro de que quiere restaurar la versión #{$a}?';
$string['restoreerror'] = 'La versión #{$a} no se ha podido restaurar';
$string['restorethis'] = 'Restaurar esta versión';
$string['restoreversion'] = 'Restaurar la versión antigua';
$string['restoring'] = 'Restaurando la versión #{$a}';
$string['return'] = 'Regresar';
$string['save'] = 'Guardar';
$string['saving'] = 'Guardando la página wiki';
$string['savingerror'] = 'Error al guardar';
$string['search:activity'] = 'Wiki - información de actividad';
$string['search:collaborative_page'] = 'Wiki - páginas colaborativas';
$string['searchcontent'] = 'Buscar en el contenido de la página';
$string['searchresult'] = 'Resultados de la búsqueda:';
$string['searchterms'] = 'Términos de búsqueda';
$string['searchwikis'] = 'Buscar wikis';
$string['special'] = 'Especial';
$string['tableofcontents'] = 'Tabla de contenidos';
$string['tagarea_wiki_pages'] = 'Páginas Wiki';
$string['tagsdeleted'] = 'Las marcas wiki se han eliminado';
$string['teacherrating'] = 'Clasificación por profesor';
$string['timesrating'] = 'Esta página ha sido clasificada  {$a->c} veces con un promedio de: {$a->s}';
$string['updatedpages'] = 'Páginas actualizadas';
$string['updatedpages_help'] = 'Páginas wiki actualizadas recientemente';
$string['updatedwikipages'] = 'Páginas wiki actualizadas';
$string['upload'] = 'Subir y eliminar';
$string['uploadactions'] = 'Acciones';
$string['uploadfiletitle'] = 'Anexos';
$string['uploadname'] = 'Nombre de archivo';
$string['uploadtitle'] = 'Adjuntar archivos';
$string['version'] = 'Versión';
$string['versionerror'] = 'La ID de la versión no existe';
$string['versionnum'] = 'Versión #{$a}';
$string['view'] = 'Ver';
$string['viewallhistory'] = 'Ver la historia completa';
$string['viewcurrent'] = 'Versión actual';
$string['viewperpage'] = 'Mostrar {$a} versiones por página';
$string['viewversion'] = 'Viendo la versión de página #{$a}';
$string['wiki'] = 'Wiki';
$string['wiki:addinstance'] = 'Añadir nuevo wiki';
$string['wiki:createpage'] = 'Crear nuevas páginas wiki';
$string['wiki:editcomment'] = 'Agregar comentarios a las páginas';
$string['wiki:editpage'] = 'Editar páginas wiki';
$string['wiki:managecomment'] = 'Gestionar comentarios wiki';
$string['wiki:managefiles'] = 'Administrar ficheros del wiki';
$string['wiki:managewiki'] = 'Gestionar ajustes wiki';
$string['wiki:overridelock'] = 'Anular bloqueos de wiki';
$string['wiki:viewcomment'] = 'Ver los comentarios de la página';
$string['wiki:viewpage'] = 'Ver páginas wiki';
$string['wikiattachments'] = 'Anexos Wiki';
$string['wikiboldtext'] = 'Texto en negrita';
$string['wikiexternalurl'] = 'URL externa';
$string['wikifiles'] = 'Ficheros del wiki';
$string['wikifiletable'] = 'Lista de archivos subidos';
$string['wikiheader'] = 'Cabecera de nivel {$a}';
$string['wikihr'] = 'Regla horizontal';
$string['wikiimage'] = 'Imagen';
$string['wikiinternalurl'] = 'Enlace externo';
$string['wikiintro'] = 'Descripción';
$string['wikiitalictext'] = 'Texto en cursiva';
$string['wikilockingsettings'] = 'Bloqueando y reanalizando tiempos de espera';
$string['wikimode'] = 'Modo Wiki';
$string['wikimode_help'] = 'El modo wiki determina si cualquiera puede editar la wiki (wiki colaborativa) o si cualquiera tiene su propia wiki que sólo esa persona puede editar (wiki individual).';
$string['wikimodecollaborative'] = 'Wiki colaborativa';
$string['wikimodeindividual'] = 'Wiki individual';
$string['wikiname'] = 'Nombre de la wiki';
$string['wikinowikitext'] = 'Sin texto wiki';
$string['wikiorderedlist'] = 'Lista ordenada';
$string['wikipages'] = 'Páginas wiki';
$string['wikisettings'] = 'Ajustes wiki';
$string['wikiunorderedlist'] = 'Lista desordenada';
$string['wrongversionlock'] = 'Otro usuario ha editado esta página mientras usted estaba editando: su contenido es obsoleto.';
$string['wrongversionsave'] = 'Otro usuario ha creado una versión mientras usted estaba editando, y usted ha sobreescrito sus cambios: compruebe la historia de la página.';
