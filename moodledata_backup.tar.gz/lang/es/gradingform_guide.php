<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'gradingform_guide', language 'es', version '4.5'.
 *
 * @package     gradingform_guide
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addcomment'] = 'Añadir comentario predefinido';
$string['addcriterion'] = 'Añadir criterio';
$string['additionalcomments'] = 'Comentarios adicionales';
$string['additionalcommentsforcriterion'] = 'Comentarios adicionales para el criterio, {$a}';
$string['alwaysshowdefinition'] = 'Mostrar las definiciones de la guía a los estudiantes';
$string['backtoediting'] = 'Atrás para editar';
$string['clicktocopy'] = 'Pulsar para copiar este texto en la retroalimentación del criterio';
$string['clicktoedit'] = 'Pulsar para editar';
$string['clicktoeditname'] = 'Pulsar para editar criterio';
$string['comment'] = 'Comentario';
$string['commentpickerforcriterion'] = 'Selector de comentarios de uso frecuente para {$a} comentarios adicionales';
$string['comments'] = 'Comentarios predefinidos';
$string['commentsdelete'] = 'Borrar comentario';
$string['commentsempty'] = 'Pulsar para editar el comentario';
$string['commentsmovedown'] = 'Mover abajo';
$string['commentsmoveup'] = 'Mover arriba';
$string['confirmdeletecriterion'] = '¿Está seguro que quiere eliminar este elemento?';
$string['confirmdeletelevel'] = '¿Está seguro que quiere eliminar este nivel?';
$string['criterion'] = 'Nombre del criterio';
$string['criteriondelete'] = 'Eliminar criterio';
$string['criterionempty'] = 'Pulsar para editar criterio';
$string['criterionmovedown'] = 'Mover abajo';
$string['criterionmoveup'] = 'Mover arriba';
$string['criterionname'] = 'Nombre del criterio';
$string['criterionremark'] = 'Comentario del criterio {$a}';
$string['definemarkingguide'] = 'Definir guía de evaluación';
$string['description'] = 'Descripción';
$string['descriptionmarkers'] = 'Descripción para los evaluadores';
$string['descriptionstudents'] = 'Descripción para los estudiantes';
$string['err_maxscoreisnegative'] = 'La nota máxima no es válida, los valores negativos no están permitidos';
$string['err_maxscorenotnumeric'] = 'La puntuación máxima del criterio debe ser numérica';
$string['err_nocomment'] = 'El comentario no puede dejarse en blanco';
$string['err_nodescription'] = 'La descripción para los estudiantes no puede dejarse en blanco';
$string['err_nodescriptionmarkers'] = 'La descripción para los evaluadores no puede dejarse en blanco';
$string['err_nomaxscore'] = 'La puntuación máxima del criterio no puede dejarse en blanco';
$string['err_noshortname'] = 'El nombre del criterio no puede dejarse en blanco';
$string['err_scoreinvalid'] = 'La puntuación dada a {$a->criterianame} no es válida, la puntuación máxima es: {$a->maxscore}';
$string['err_scoreisnegative'] = 'La puntuación dada a \'{$a->criterianame}\' no es válida, los valores negativos no están permitidos.';
$string['err_shortnametoolong'] = 'El criterio para establecer un nombre obliga a incluir menos de 256 caracteres';
$string['gradingof'] = 'Calificando {$a}';
$string['guide'] = 'Guía de evaluación';
$string['guidemappingexplained'] = 'ADVERTENCIA: Esta guía de evaluación puede puntuarse como máximo hasta {$a->maxscore} puntos, pero la puntuación máxima establecida para la actividad es de {$a->modulegrade} puntos.

La puntuación máxima de la guía de evaluación se modificada proporcionalmente para hacerla equivalente a la calificación máxima de la tarea. Las calificaciones intermedias también se convertirán y redondearán según este criterio.';
$string['guidenotcompleted'] = 'Por favor, de una calificación válida para este criterio.';
$string['guideoptions'] = 'Opciones de la guía de evaluación';
$string['guidestatus'] = 'Estado actual de la guía de evaluación';
$string['hidemarkerdesc'] = 'Ocultar las descripciones de los criterios de puntuación';
$string['hidestudentdesc'] = 'Ocultar las descripciones del criterio para el estudiante';
$string['informationforcriterion'] = 'Información de {$a}';
$string['insertcomment'] = 'Insertar el comentario usado con más frecuencia';
$string['maxscore'] = 'Puntuación máxima';
$string['name'] = 'Nombre';
$string['needregrademessage'] = 'La definición de la guía de evaluación fue cambiada posteriormente a que este alumno fuera calificado. El alumno no verá  esta guía de calificación hasta que usted valide la guía de evaluación y actualice la calificación.';
$string['outof'] = 'Puntuación sobre {$a}';
$string['pluginname'] = 'Guía de evaluación';
$string['previewmarkingguide'] = 'Vista previa de la guía de evaluación';
$string['privacy:metadata:criterionid'] = 'Un identificador de un criterio de calificación avanzada.';
$string['privacy:metadata:fillingssummary'] = 'Almacena información sobre la calificación de un alumno y la retroalimentación para la guía de calificación.';
$string['privacy:metadata:instanceid'] = 'Un identificador de una calificación utilizada por una actividad.';
$string['privacy:metadata:preference:showmarkerdesc'] = 'Si mostrar descripciones de los criterios de calificación';
$string['privacy:metadata:preference:showstudentdesc'] = 'Si mostrar las descripciones de los criterios a los estudiantes';
$string['privacy:metadata:remark'] = 'Comentarios relacionados con este criterio de evaluación.';
$string['privacy:metadata:score'] = 'Una puntuación para este criterio de calificación.';
$string['regrademessage1'] = 'Está a punto de guardar cambios en una guía de evaluación que ya ha sido utilizada para calificar. Por favor, indique si las calificaciones existentes deben ser revisadas. Si así lo establece, la guía de calificacion se ocultará a los estudiantes hasta que sean recalificados.';
$string['regrademessage5'] = 'Está a punto de guardar cambios en una guía de evaluación que ya ha sido utilizada para calificar. La calificación guardada en el libro de calificaciones no se modificará, pero la guía de calificaciones se ocultará a los estudiantes hasta que sean recalificados.';
$string['regradeoption0'] = 'No recalificar';
$string['regradeoption1'] = 'Recalificar';
$string['remark_help'] = 'Introduzca cualquier comentario adicional sobre este criterio.';
$string['restoredfromdraft'] = 'NOTA: El último intento de calificación de este estudiante no se ha guardado correctamente, por lo que se han restaurado las calificaciones anteriores guardadas como borrador. Si desea cancelar estos cambios pulse sobre el botón "Cancelar"';
$string['save'] = 'Guardar';
$string['saveguide'] = 'Guardar la guía de evaluación para su uso';
$string['saveguidedraft'] = 'Guardar como borrador';
$string['score'] = 'Puntuación';
$string['score_help'] = 'Introduzca una puntuación para {$a->criterion} entre 0 y {$a->maxscore}.';
$string['scoreforcriterion'] = 'Puntuación {$a}';
$string['showmarkerdesc'] = 'Mostrar las descripciones de los criterios de puntuación';
$string['showmarkspercriterionstudents'] = 'Mostrar las puntuaciones por criterio a los estudiantes';
$string['showstudentdesc'] = 'Mostrar la descripció para el estudiante de los criterios';
