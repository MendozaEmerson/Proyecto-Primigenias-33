<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'supervideo', language 'es', version '4.5'.
 *
 * @package     supervideo
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['autoplay'] = 'Reproducir automáticamente';
$string['autoplay_desc'] = 'Reproducir automáticamente al cargar el reproductor';
$string['completiondetail:completionpercent'] = 'Tienes que ver {$a}% del video';
$string['completionpercent'] = 'Requiere porcentaje';
$string['completionpercent_error'] = 'Aceptar valores de 1 a 100';
$string['completionpercent_help'] = 'Se considera completo cuando el estudiante visualiza el porcentaje establecido del video. Acepta valores de 1 a 100.';
$string['completionpercent_label'] = 'Habilitar:&amp;nbsp;';
$string['controls'] = 'Controles';
$string['controls_captions'] = 'Subtítulos';
$string['controls_current-time'] = 'Tiempo actual';
$string['controls_desc'] = 'Define qué controles se mostrarán para cargas o archivos.';
$string['controls_duration'] = 'Duración';
$string['controls_fastForward'] = 'Avanzar rápido';
$string['controls_fullscreen'] = 'Pantalla completa';
$string['controls_mute'] = 'Silencio';
$string['controls_pause'] = 'Pausar';
$string['controls_pip'] = 'Imagen en imagen';
$string['controls_play'] = 'Reproducir';
$string['controls_progress'] = 'Progreso';
$string['controls_restart'] = 'Reiniciar';
$string['controls_rewind'] = 'Retroceder';
$string['controls_settings'] = 'Configuración';
$string['controls_volume'] = 'Volumen';
$string['distractionfreemode'] = 'Modo sin distracciones para videos';
$string['distractionfreemode_desc'] = 'Esta opción permite que los videos se muestren en modo sin distracciones, ocultando elementos de la interfaz que puedan desviar la atención y proporcionando una experiencia de visualización más enfocada.<br>Si la inserción es desde Google Drive con tamaños PDF/DOC/XLS, no se habilitará.';
$string['distractionfreemode_h5p'] = 'Experiencia sin distracciones para el H5P de OttFlix';
$string['distractionfreemode_h5p_desc'] = 'Esta opción te permite mostrar los H5P creados en OttFlix en modo sin distracciones, ocultando elementos de la interfaz que puedan desviar la atención y garantizando una experiencia de visualización más limpia y enfocada.';
$string['dnduploadlabel-mp3'] = 'Agregar Audio con Super Video';
$string['dnduploadlabel-mp4'] = 'Agregar Video con Super Video';
$string['dnduploadlabeltext'] = 'Agregar video con Super Video';
$string['error_default'] = 'Ocurrió un error desconocido.';
$string['error_media_err_aborted'] = 'Has cancelado la reproducción del video.';
$string['error_media_err_decode'] = 'La reproducción del video fue cancelada debido a un problema de corrupción o porque el video usaba funciones que tu navegador no soporta.';
$string['error_media_err_network'] = 'Un error de red provocó que la descarga del video fallara a mitad de camino.';
$string['error_media_err_src_not_supported'] = 'No se pudo cargar el video, ya sea porque el servidor o la red fallaron o porque el formato no es compatible.';
$string['filenotfound'] = '¡Archivo no encontrado!';
$string['freemode_focus'] = 'Enfoque';
$string['freemode_focusmode'] = 'Modo enfoque';
$string['grade_approval'] = 'Establecer calificación para';
$string['grade_approval_0'] = 'Sin calificaciones';
$string['grade_approval_1'] = 'Calificación basada en el porcentaje de visualización del video';
$string['idnotfound'] = 'Enlace no reconocido como Youtube, Google Drive o Vimeo';
$string['kapture_aborted_upload_ottflix'] = '¡La subida a OttFlix fue cancelada!';
$string['kapture_app_title'] = 'OTTFlix Kapture';
$string['kapture_approve_permission'] = 'Seleccione <b><i>Permitir</i></b> cuando su navegador solicite permisos.';
$string['kapture_camera'] = 'Cámara';
$string['kapture_camera_size'] = 'Tamaño de la cámara';
$string['kapture_contact_support_error'] = 'Contacte con soporte e informe del error';
$string['kapture_countdown'] = 'Cuenta regresiva';
$string['kapture_erro_camera_microfone.'] = 'Ocurrió un error al solicitar acceso a la cámara y al micrófono.';
$string['kapture_error'] = 'Error:';
$string['kapture_error_accessing_camera'] = 'Error al acceder a la cámara o capturar la pantalla';
$string['kapture_finish'] = 'Finalizar';
$string['kapture_finish_recording'] = 'Finalizar grabación';
$string['kapture_fullscreen'] = 'Pantalla completa';
$string['kapture_inverter_camera'] = 'Voltear cámara';
$string['kapture_layout_1'] = 'Diseño 1';
$string['kapture_layout_2'] = 'Diseño 2';
$string['kapture_layout_3'] = 'Diseño 3';
$string['kapture_layout_4'] = 'Diseño 4';
$string['kapture_layout_5'] = 'Diseño 5';
$string['kapture_layout_6'] = 'Diseño 6';
$string['kapture_layout_cam'] = 'Diseño de cámara';
$string['kapture_layout_presentation'] = 'Diseño de presentación';
$string['kapture_loading_documents'] = 'Cargando documentos...';
$string['kapture_logo_title'] = 'Logo';
$string['kapture_microfone'] = 'Micrófono';
$string['kapture_none_camera'] = 'No usar la cámara';
$string['kapture_not_supported_mobile'] = 'No compatible en móviles';
$string['kapture_or'] = 'o';
$string['kapture_ottflix'] = 'OttFlix';
$string['kapture_ottflix_upload_failure'] = 'Error al subir a OttFlix';
$string['kapture_processing'] = 'Procesando...';
$string['kapture_requires_camera'] = 'Kapture necesita acceso a su micrófono y cámara.';
$string['kapture_round_camera'] = 'Cámara redonda';
$string['kapture_save_computer'] = 'Guardar en el equipo';
$string['kapture_save_ottflix'] = 'Enviar a OttFlix';
$string['kapture_save_recording_ottflix'] = 'Guarde su grabación en OttFlix';
$string['kapture_search_files'] = 'Buscar archivos';
$string['kapture_select_presentation'] = 'Selecciona la presentación';
$string['kapture_select_slide'] = 'Seleccionar diapositiva';
$string['kapture_send_new'] = 'Enviar nuevo';
$string['kapture_share_audio_system'] = 'Compartir audio del sistema';
$string['kapture_start_recording'] = 'Iniciar grabación';
$string['kapture_start_recording_fullscreen'] = 'Iniciar grabación en pantalla completa';
$string['kapture_switched_off'] = 'apagado';
$string['kapture_this_tab'] = 'Esta pestaña';
$string['kapture_title_too_short'] = '¡Título demasiado corto!';
$string['kapture_upload_completed'] = 'Carga completada. ¡En espera para ser procesada!';
$string['kapture_video_default_title'] = 'Título del video';
$string['kapture_video_title'] = 'Capturar';
$string['kapture_video_title_desc'] = 'Elija un nombre que sea fácil de encontrar más tarde.';
$string['maxwidth'] = 'Ancho Máximo para el Reproductor de Video';
$string['maxwidth_desc'] = 'Ancho máximo, en píxeles, al que puede expandirse el reproductor de video. Se considerarán valores inferiores a 500 píxeles.<br>Este valor se ignora completamente cuando el video está en "Modo sin distracciones."';
$string['modulename'] = 'Super Video';
$string['modulename_help'] = 'Este módulo añade un Super Video dentro de Moodle.';
$string['modulenameplural'] = 'Super Videos';
$string['no_data'] = 'Sin registros';
$string['origem_drive'] = 'Video desde Google Drive';
$string['origem_drive_help'] = 'Enlace a un video almacenado en tu Google Drive. Asegúrate de ajustar la configuración de uso compartido para permitir el acceso al video.';
$string['origem_embed'] = 'Incrustación personalizada (iframe)';
$string['origem_embed_help'] = 'Utilice esta opción para incrustar un reproductor de video personalizado mediante iframe. Pegue la URL completa de la página de su reproductor incrustado (p. ej. https://example.com/embed/player/?src=https://example.com/video.m3u8).';
$string['origem_link'] = 'Enlace a un video';
$string['origem_link_help'] = 'Usa esta opción para proporcionar una URL directa a cualquier fuente de video. Asegúrate de que el enlace sea válido y accesible.';
$string['origem_name'] = 'Fuente del video';
$string['origem_ottflix'] = 'Enlace o identificador de OttFlix';
$string['origem_ottflix_help'] = 'Usa esta opción para vincular a un video disponible en OttFlix. Puedes introducir el enlace o el identificador del video.';
$string['origem_pandavideo'] = 'Video de Panda Video';
$string['origem_pandavideo_help'] = 'Enlace a un video almacenado en tu Panda Video.';
$string['origem_upload'] = 'Subir un video';
$string['origem_upload_help'] = 'Selecciona esta opción para subir un archivo de video directamente desde tu dispositivo. Los formatos compatibles incluyen MP3, MP4, WEBM, M4V, MOV, AAC y M4A.';
$string['origem_vimeo'] = 'Video desde Vimeo';
$string['origem_vimeo_help'] = 'Proporciona la URL de un video de Vimeo. Asegúrate de que el video sea de acceso público y no tenga contraseña.';
$string['origem_youtube'] = 'Video desde YouTube';
$string['origem_youtube_help'] = 'Introduce la URL de un video público de YouTube. Asegúrate de que el video no esté configurado como privado o restringido.';
$string['ottflix'] = 'Módulo Super Video';
$string['ottflix_ia'] = 'Mostrar funciones de IA disponibles en OttFlix';
$string['ottflix_ia_accordion'] = 'Glosario';
$string['ottflix_ia_advancedtext'] = 'Libro digital';
$string['ottflix_ia_desc'] = 'Cuando selecciones cualquiera de las opciones de IA a continuación, el video se mostrará en formato <strong>H5P</strong> dentro de tu actividad. Todas las funciones elegidas se insertarán automáticamente en el contenido H5P.<br>
- Si habilitas <strong>solo</strong> <a target="_blank" href="https://h5p.org/interactive-video" target="_blank" rel="noopener">Video interactivo</a>, el resultado será un simple video interactivo H5P.<br>
- Si habilitas otros elementos además de Video interactivo, el contenido se entregará en formato <a target="_blank" href="https://h5p.org/content-types/interactive-book" target="_blank" rel="noopener">Libro interactivo</a>, con Video interactivo como primer elemento.';
$string['ottflix_ia_dialogcards'] = 'Tarjetas de memoria';
$string['ottflix_ia_dragtext'] = 'Juego Arrastra las palabras';
$string['ottflix_ia_interactivevideo'] = 'Video interactivo';
$string['ottflix_ia_questionset'] = 'Cuestionarios';
$string['ottflix_title'] = 'Integración con OttFlix';
$string['ottflix_token'] = 'Token de acceso de OttFlix';
$string['ottflix_token_desc'] = 'Introduce el token de acceso de OttFlix para autenticar la solicitud.';
$string['ottflix_url'] = 'URL de OttFlix';
$string['ottflix_url_desc'] = 'Introduce la URL de OttFlix para la integración.';
$string['pandavideo_title'] = 'Panda Videos';
$string['pandavideo_title_desc'] = 'Integración con el servicio de transmisión Panda Videos para mostrar contenido alojado en la plataforma. Más información en <a href="https://pandavideo.com.br/?ref=mjy1ndz" target="_blank" rel="noopener noreferrer">pandavideo.com.br</a>.';
$string['playersize'] = 'Tamaño del video';
$string['pluginadministration'] = 'Super Videos';
$string['pluginname'] = 'Super Video';
$string['privacy:metadata'] = 'El complemento supervideo no envía ningún dato personal a terceros.';
$string['privacy:metadata:supervideo_view'] = 'Un registro de la interacción del estudiante con el reproductor de video, como los eventos de reproducción y pausa.';
$string['privacy:metadata:supervideo_view:cm_id'] = 'El ID del módulo del curso donde se encuentra el video.';
$string['privacy:metadata:supervideo_view:currenttime'] = 'El tiempo actual de reproducción del video cuando se registró la interacción.';
$string['privacy:metadata:supervideo_view:duration'] = 'La duración total del video en segundos.';
$string['privacy:metadata:supervideo_view:map'] = 'JSON del mapa de vistas';
$string['privacy:metadata:supervideo_view:percent'] = 'El porcentaje del video visto por el estudiante.';
$string['privacy:metadata:supervideo_view:timecreated'] = 'La marca de tiempo cuando se creó el registro de interacción con el video.';
$string['privacy:metadata:supervideo_view:timemodified'] = 'La marca de tiempo cuando se modificó por última vez el registro de interacción con el video.';
$string['privacy:metadata:supervideo_view:user_id'] = 'El ID del estudiante que interactuó con el video.';
$string['record_kapture'] = 'Graba tu video con Kapture';
$string['report'] = 'Informe';
$string['report_all'] = 'Todas las vistas de este estudiante';
$string['report_assistiu'] = 'Visto cuando';
$string['report_comecou'] = 'Comenzó a ver cuando';
$string['report_duracao'] = 'Duración del video';
$string['report_email'] = 'Correo electrónico';
$string['report_filename'] = 'Vista previa del video del plugin Super Video - {$a}';
$string['report_filename_geral'] = 'General';
$string['report_nome'] = 'Nombre completo';
$string['report_porcentagem'] = 'Porcentaje visto';
$string['report_tempo'] = 'Tiempo visto';
$string['report_terminou'] = 'Terminó de ver cuando';
$string['report_title'] = 'Informe';
$string['report_userid'] = 'ID de usuario';
$string['report_visualizacoes'] = 'Visualizaciones';
$string['repository_ottflix_disable'] = 'El repositorio OttFlix está instalado pero no habilitado. <a href="{$a}/admin/repository.php">Haz clic aquí para habilitarlo</a> y facilitar la organización de tus videos y archivos.';
$string['repository_ottflix_notinstall'] = 'El repositorio OttFlix no está instalado. Recomendamos <a href="https://moodle.org/plugins/repository_ottflix">hacer clic aquí</a> para instalarlo y simplificar el acceso y la organización de tus videos y archivos.';
$string['repository_pandavideo_disable'] = 'El repositorio Panda Video está instalado pero no habilitado. <a href="{$a}/admin/repository.php">Haz clic aquí para habilitarlo</a> y optimizar el uso de tus videos.';
$string['repository_pandavideo_notinstall'] = 'El repositorio Panda Video no está instalado. Recomendamos <a href="https://moodle.org/plugins/repository_pandavideo">hacer clic aquí</a> para instalarlo y facilitar la búsqueda y el uso de tus videos.';
$string['settings_obrigatorio_desmarcado'] = 'Estará deshabilitado para todos y no hay forma de editarlo en el FORMULARIO';
$string['settings_obrigatorio_marcado'] = 'Estará activado para todos y no hay forma de editarlo en el FORMULARIO';
$string['settings_opcional_desmarcado'] = 'El FORMULARIO aparecerá desactivado y el profesor podrá activarlo o desactivarlo';
$string['settings_opcional_marcado'] = 'En el FORMULARIO aparecerá activado y el profesor podrá activarlo o desactivarlo';
$string['showcontrols'] = 'Mostrar controles';
$string['showcontrols_desc'] = 'Mostrar controles del reproductor para YouTube y Vimeo.';
$string['speed'] = 'Control de velocidad';
$string['speed_0_5'] = 'Velocidad 0.5x';
$string['speed_0_75'] = 'Velocidad 0.75x';
$string['speed_1'] = 'Velocidad normal';
$string['speed_1_25'] = 'Velocidad 1.25x';
$string['speed_1_5'] = 'Velocidad 1.5x';
$string['speed_1_75'] = 'Velocidad 1.75x';
$string['speed_2'] = 'Velocidad 2x';
$string['speed_4'] = 'Velocidad 4x';
$string['speed_desc'] = 'Definir qué opciones de velocidad se mostrarán en el reproductor';
$string['supervideo:addinstance'] = 'Crear nuevas actividades con Super Video';
$string['supervideo:view'] = 'Ver e interactuar con Super Video';
$string['supervideo:view_report'] = 'Ver informes de SuperVideo';
$string['videofile'] = 'O selecciona un archivo MP3, MP4 o WebM';
$string['videofile_help'] = 'Puedes subir un archivo MP3 o MP4, alojarlo en MoodleData y mostrarlo en el reproductor de Super Video';
$string['videourl_error'] = 'URL de Super Video';
$string['videourl_help'] = '<h4>Youtube</h4>
<div>Agrega una URL de Youtube que deseas añadir al curso:</div>
<div><strong>Ej:</strong> https://www.youtube.com/watch?v=SNhUMChfolc</div>
<div><strong>Ej:</strong> https://youtu.be/kwjhXQUpyvA</div>
<h4>Google Drive</h4>
<div>En Google Drive, haz clic en compartir video, establece permisos y pega el enlace aquí.</div>
<h4>Vimeo</h4>
<div>Agrega una URL de Vimeo que deseas añadir al curso:</div>
<div><strong>Ej:</strong> https://vimeo.com/300138942</div>
<h4>Video o audio externo</h4>
<div>Agrega una URL de un video que hayas alojado en tu propio servidor:</div>
<div><strong>Ej:</strong> https://host.com.br/file/video.mp4</div>
<div><strong>Ej:</strong> https://host.com.br/file/video.mp3</div>';
